import numpy
import cv2
import tensorflow
import torch

def add_one(number):
    return number + 1
